<style>
  body {
    margin: 0;
    padding: 0;
  }

  .cursor_pointer:hover {
    cursor: pointer;
  }
  .card h2 {
    text-align: center;
  }
  .card p {
  text-align: justify;
  }

 

 
body{

  overflow-y: scroll;
  scrollbar-color: #584e80 black;
}
 
</style>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
<style>
body {
  font-family: "Sofia", sans-serif;
}
h3 {
  text-align: justify;
}
#data_all_colors{
  background-color:black;
}
.information_user_reg_date_{
  color: rgba(0,0,0,0.4);
  margin-bottom: 60px;
  margin-top: 60px;
}
input{
  width: 100%;
}

.information_user_reg_date_2{
  font-weight: bold;
  text-shadow:  1px 1px black;
}
 
</style>
<style>
      .remove_block{
            margin-top: 40px;
            margin-bottom: 40px;

      } 
  #add_projet {
    display: none;
  }

    .plus_element{
        margin-top: 100px;
    }
        .img_background_ {
            margin-top: 50px; 
            margin-bottom: 50px; 
            max-width: 100%;
            max-height: 400px;
         
            position: relative;
            height: 100%;
            overflow: hidden; /* Empêche l'image de dépasser la hauteur de la div */
            background-color: black; 
            min-height: 100px;
            min-width: 100px;

        }

        .img_background_ img:hover {
            cursor: pointer;
        }

        .img_background_ img {
            max-height: 100%; /* Limite la hauteur de l'image à la hauteur de la div */
            width: auto; /* Maintient le ratio d'aspect de l'image */
            display: block; /* Évite les espaces indésirables sous l'image */
            margin: auto; /* Centre l'image horizontalement si elle est plus petite */
            position: relative;
            background-color: black; 
            margin-top: 50px;
            margin-bottom: 50px;
        }
        .img_background_:hover{
          cursor: pointer;
        }

        /*    */

     

        .img_background_2 img:hover {
            cursor: pointer;
        }

        .img_background_2 img {
            max-height: 100%; /* Limite la hauteur de l'image à la hauteur de la div */
            width: auto; /* Maintient le ratio d'aspect de l'image */
            display: block; /* Évite les espaces indésirables sous l'image */
            margin: auto; /* Centre l'image horizontalement si elle est plus petite */
            position: relative;
            background-color: black; 
        }
        .img_background_2:hover{
          cursor: pointer;
        }

        .img_background_2{
           max-width: 50%;
           min-height: 50%;
           text-align: center;
           min-height: 100px;
            min-width: 100px;
            background-color: rgba(0,0,0,0.4);
           margin: auto;
        }
        .img_background_2 img{
        width: 100%;
        text-align: center;
        }
        textarea{
            width: 100%;
            height: 200px;
            color: black;
        }
        .card h1 {
     
            text-align: center;
        
        }

        h3 {
          margin-top: 60px; 
          margin-bottom: 60px;
        }
    </style>