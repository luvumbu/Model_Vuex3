<input type="text" placeholder="Entrez votre adresse mail">
<input type="button" value="Envoyer mot de passe de récuperation" title="Connexion" id="btn_connexion" class="index_class_4 cursor_pointer"
        onclick="information_user_btn(this)">