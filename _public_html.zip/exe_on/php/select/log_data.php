<?php  
$information_user_id_sha1 = $_SESSION["information_user_id_sha1"] ;
?>