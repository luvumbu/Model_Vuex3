<?php

$liste_projet_admin_id_->getDataFromTable($info_sql, "liste_projet_admin_id");
$liste_projet_admin_id_sha1_->getDataFromTable($info_sql, "liste_projet_admin_id_sha1");
$liste_projet_admin_id_sha1_user_->getDataFromTable($info_sql, "liste_projet_admin_id_sha1_user");
$liste_projet_admin_name1_->getDataFromTable($info_sql, "liste_projet_admin_name1");
$liste_projet_admin_name2_->getDataFromTable($info_sql, "liste_projet_admin_name2");
// source 1 
//$liste_projet_admin_img_path_->getDataFromTable($info_sql, "liste_projet_admin_img_path");
// Source 2
$liste_projet_admin_img_path_->getDataFromTable($info_sql, "liste_projet_admin_img_path_");


$information_user_reg_date_->getDataFromTable($info_sql, "information_user_reg_date");




 

$liste_projet_admin_id_sha1_user___ = $liste_projet_admin_id_sha1_user_->tableList_info[0]  ; 


 


?>