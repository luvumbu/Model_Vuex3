<?php
$servername = 'localhost'; // Nom du serveur
$username = 'u489596434_bkbk'; // Nom d'utilisateur de la base de données
$password = 'v3p9r3e@59A'; // Mot de passe de la base de données
$dbname = 'u489596434_bkbk'; // Nom de la base de données
?>