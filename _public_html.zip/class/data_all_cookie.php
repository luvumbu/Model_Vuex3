<?php
 
session_start() ; 


$_SESSION['liste_projet_admin_insert'] = $_POST["liste_projet_admin_id_sha1"]; 


 
?>