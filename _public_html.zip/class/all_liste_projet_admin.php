<?php 
session_start() ; 


 $_SESSION["all_liste_projet_admin"]="on";


 echo  $_SESSION["all_liste_projet_admin"] ; 
 ?>